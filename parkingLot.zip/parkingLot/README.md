GOJEK Parking lot Problem

### Project Requirements

* JDK 1.8.

* Maven 2.

* Junit 4.12

The project can be run as follows in one of the two ways :
1) ./parking_lot.sh  <input_filepath>  
   The inputs commands are expected and taken from the file specified
2) ./parking_lot.sh 
   This will start the program in interactive mode.