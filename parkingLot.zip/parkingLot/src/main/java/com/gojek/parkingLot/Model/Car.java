package com.gojek.parkingLot.Model;

public class Car extends Vehicle {

	
	public Car(String registrationNo, String color) {
		super(registrationNo, color);
	}

	

}
